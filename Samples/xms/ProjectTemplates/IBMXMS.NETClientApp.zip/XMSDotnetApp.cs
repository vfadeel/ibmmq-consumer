﻿/* @(#) MQMBID sn=p930-L220607.DE su=_T1YMxuZZEeywe89ziwFDLA pn=xms/dotnetclient/src/samples/core/xms/ProjectTemplates/XMSDotnetApp.cs                                               */
/*********************************************************************/
/*   <copyright                                                      */
/*   notice="lm-source-program"                                      */
/*   pids="5724-H72,"                                                */
/*   year="2020"                                                     */
/*   crc="2787562084" >                                              */
/*   Licensed Materials - Property of IBM                            */
/*                                                                   */
/*   5724-H72,                                                       */
/*                                                                   */
/*   (C) Copyright IBM Corp. 2020 All Rights Reserved.               */
/*                                                                   */
/*   US Government Users Restricted Rights - Use, duplication or     */
/*   disclosure restricted by GSA ADP Schedule Contract with         */
/*   IBM Corp.                                                       */
/*   </copyright>                                                    */
/*********************************************************************/
using System;
using IBM.XMS;
namespace IBM.XMS.Apps
{
    class XMSDotnetApp
    {
        static void Main()
        {
            try
            {
                /* XMS .NET Developers reference guide https://www.ibm.com/support/knowledgecenter/en/SSFKSJ_latest/com.ibm.mq.dev.doc/xms_tprog_net.htm
                 * Follow the below administrative steps if required before running the sample
                 *  1) Modify the connection properties i.e XMSC.WMQ_HOST_NAME,XMSC.WMQ_PORT and
                 *     XMSC.WMQ_CHANNEL as per your queue manager setup 
                    2) For Point-Point operations create queue "Q1" or update code(in function SendMessage/ReceiveMessage)to use an existing queue from your setup.
                 *  3) For Publish/Subscribe create topic object "Sports"  or update code(in function SendMessage/ReceiveMessage)to use an existing topic from your setup.
                */
                XMSDotnetApp xmsClient = new XMSDotnetApp();
                Console.WriteLine("IBM XMS .NET Client");
                /* The below line of code Puts a message onto the IBM MQ Queue. */
                  xmsClient.SendMessage("Q1");
                /* Uncomment the below line of code to Publish a message onto the IBM MQ Topic. */
                //xmsClient.SendMessage("Sports",false);
                /* Uncomment the below line of code to Get a message from the IBM MQ Queue */
                //xmsClient.ReceiveMessage("Q1");
                /* Uncomment the below line of code to Get a subscription from IBM MQ Topic */
                //xmsClient.ReceiveMessage("Sports",false);
            }
            catch (XMSException e)
            {
                Console.WriteLine(e);
            }
        }

        /// <summary>
        /// Connect to the Queue Manager
        /// </summary>
        /// <returns>IConnection object</returns>
        private IConnection CreateConnection()
        {
            try
            {
                // Create ConnectionFactory
                IConnectionFactory cf = XMSFactoryFactory.GetInstance(XMSC.CT_WMQ).CreateConnectionFactory();
                // Set the properties
                cf.SetStringProperty(XMSC.WMQ_HOST_NAME, "localhost");
                cf.SetIntProperty(XMSC.WMQ_PORT, 3636);
                cf.SetStringProperty(XMSC.WMQ_CHANNEL, "SYSTEM.DEF.SVRCONN");
                cf.SetIntProperty(XMSC.WMQ_CONNECTION_MODE, XMSC.WMQ_CM_CLIENT);
                /* incase logged-in user id doesn't have necessary permissions.Uncomment the code below to add a user who have the required permission */
                //cf.SetStringProperty(XMSC.USERID, "mqadmin");
                //cf.SetStringProperty(XMSC.PASSWORD, "mqadmin");
                /* Uncomment this part of code if you need SSL/TLS enabled connections". Please update the properties to suite your environment. */
                //cf.SetStringProperty(XMSC.WMQ_SSL_CERT_STORES, "*USER");
                //cf.SetStringProperty(XMSC.WMQ_SSL_CIPHER_SPEC, "TLS_RSA_WITH_AES_128_CBC_SHA");
                //cf.SetStringProperty(XMSC.WMQ_SSL_PEER_NAME, "CN=IBMWEBSPHEREMQQM08i,OU=ISL,OU=MQ,OU=DOTNET,O=IBMi,C=IN,DC=SSL,DC=Client");

                return cf.CreateConnection();
            }
            catch (XMSException e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Create Session
        /// </summary>
        /// <param name="transacted">true, for creating transacted session
        ///                          false, for non-transacted session</param>
        /// <returns>ISession object</returns>
        private ISession CreateSession(bool transacted)
        {
            IConnection connection = CreateConnection();
            connection.Start();
            return connection.CreateSession(transacted, AcknowledgeMode.AutoAcknowledge);
        }

        /// <summary>
        /// Access Destination - Queue/Topic
        /// </summary>
        /// <param name="session">session object</param>
        /// <param name="destName">name of the destination: queueName/topic Name</param>
        /// <param name="isQueue">true, if destination is queue
        ///                       false, if destination is topic </param>
        /// <returns>IDestination object</returns>
        private IDestination AccessDestination(ISession session, String destName, bool isQueue = true)
        {
            if (isQueue)
                return session.CreateQueue(destName);
            else
               return session.CreateTopic(destName);              
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="destName"></param>
        /// <param name="isQueue"></param>
        /// <param name="transacted"></param>
        public void SendMessage(String destName, bool isQueue=true, bool transacted=false)
        {
            try
            {
                using (var session = CreateSession(transacted))
                {
                    IDestination destination = AccessDestination(session, destName, isQueue);
                    ITextMessage textMessage = session.CreateTextMessage("From XMS .NET Core application");
                    session.CreateProducer(destination).Send(textMessage);                    
                    Console.WriteLine("Message has been Sent Successfully");
                }
            }
            catch (XMSException e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Send/Publish message onto the destination
        /// </summary>
        /// <param name="destName">name of the destination: queueName/topic Name</param>
        /// <param name="isQueue">true, if destination is queue
        ///                       false, if destination is topic </param>
        /// <param name="transacted">true, for creating transacted session
        ///                          false, for non-transacted session</param>
        public void ReceiveMessage(String destName, bool isQueue = true, bool transacted = false)
        {
            try
            {
                using (var session = CreateSession(transacted))
                {
                    IDestination destination = AccessDestination(session, destName, isQueue);
                    Console.WriteLine(session.CreateConsumer(destination).ReceiveNoWait());                  
                }
            }
            catch (XMSException e)
            {
                throw e;
            }
        }
    }
}
