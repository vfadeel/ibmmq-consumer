﻿/* @(#) MQMBID sn=p930-L220607.DE su=_T1YMxuZZEeywe89ziwFDLA pn=basedotnet/samples/cs/core/base/ProjectTemplates/MQDotnetApp.cs                                               */
/*********************************************************************/
/*   <copyright                                                      */
/*   notice="lm-source-program"                                      */
/*   pids="5724-H72,"                                                */
/*   year="2020"                                                     */
/*   crc="2787562084" >                                              */
/*   Licensed Materials - Property of IBM                            */
/*                                                                   */
/*   5724-H72,                                                       */
/*                                                                   */
/*   (C) Copyright IBM Corp. 2020 All Rights Reserved.               */
/*                                                                   */
/*   US Government Users Restricted Rights - Use, duplication or     */
/*   disclosure restricted by GSA ADP Schedule Contract with         */
/*   IBM Corp.                                                       */
/*   </copyright>                                                    */
/*********************************************************************/
using System;
using System.Collections;
using IBM.WMQ;
namespace IBM.MQ.Apps
{
    class MQDotnetApp
    {
        static void Main()
        {
            try
            {

                /* MQ .NET Developers reference guide https://www.ibm.com/support/knowledgecenter/SSFKSJ_latest/com.ibm.mq.dev.doc/q029250_.htm
                 * Follow the below administrative steps if required before running the sample
                 *  1) Modify the connection properties i.e MQC.CONNECTION_NAME_PROPERTY and
                 *     MQC.CHANNEL_PROPERTY as per your queue manager setup
                 *  2) For Point-Point operations create queue "Q1" or update code(in function PutMessage/GetMessage)to use an existing queue from your setup.
                 *  3) For Publish/Subscribe create topic object "Sports"  or update code(in function PutMessage/GetMessage)to use an existing topic from your setup.
                */
                MQDotnetApp mqClient = new MQDotnetApp();
                Console.WriteLine("IBM MQ .NET Client");
                /* Uncomment the below line of code to Put a message onto the IBM MQ Queue. */
                mqClient.PutMessage("Q1");
                /* Uncomment the below line of code to Publish a message onto the IBM MQ Topic. */
                //mqClient.PutMessage("Sports",false);
                /* Uncomment the below line of code to Get a message from the IBM MQ Queue */
                //mqClient.GetMessage("Q1");
                /* Uncomment the below line of code to Get a subscription from IBM MQ Topic */
                //mqClient.GetMessage("Sports",false);
            }
            catch (MQException e)
            {
                Console.WriteLine(e);
            }

        }

        /// <summary>
        /// Connect to the Queue Manager
        /// </summary>
        /// <returns>MQQueueManager object</returns>
        private MQQueueManager CreateConnection()
        {
            try
            {
                MQEnvironment.properties = new Hashtable { {MQC.CONNECTION_NAME_PROPERTY,"localhost(1414)" },
                    { MQC.CHANNEL_PROPERTY,"DOTNET.SVRCONN" },
                    { MQC.TRANSPORT_PROPERTY,MQC.TRANSPORT_MQSERIES_MANAGED },
                    /* incase logged-in user id doesn't have necessary permissions.Uncomment the code below to add a user who have the required permission */
                    //{ MQC.USER_ID_PROPERTY,"mqadmin"},
                    //{ MQC.PASSWORD_PROPERTY,"mqadmin"},
                    /* Uncomment this part of code if you need SSL/TLS enabled connections". Please update the properties to suite your environment. */
                    //{ MQC.SSL_CERT_STORE_PROPERTY,"*USER"},
                    //{ MQC.SSL_CIPHER_SPEC_PROPERTY,"TLS_RSA_WITH_AES_128_CBC_SHA"},
                    //{ MQC.SSL_PEER_NAME_PROPERTY,"CN=IBMWEBSPHEREMQQM08i,OU=ISL,OU=MQ,OU=DOTNET,O=IBMi,C=IN,DC=SSL,DC=Client"},
                    //{ MQC.SSL_RESET_COUNT_PROPERTY,"45000"},

                };

                return new MQQueueManager();
            }
            catch (MQException e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Access Destination - Queue/Topic
        /// </summary>
        /// <param name="qm">MQQueueManager Object</param>
        /// <param name="destName">name of the destination: queueName/topic Name</param>
        /// <param name="isQueue">true, if destination is queue
        ///                       false, if destination is topic </param>
        /// <param name="publish">true, for publishing message onto the topic
        ///                       false,subscribing for messages from a topic </param>
        ///           
        /// <returns>MQDestination Object</returns>
        private MQDestination AccessDestination(MQQueueManager qm, String destName, bool isQueue = true, bool publish = true)
        {
            if (isQueue)
                return qm.AccessQueue(destName, MQC.MQOO_INPUT_AS_Q_DEF + MQC.MQOO_OUTPUT + MQC.MQOO_FAIL_IF_QUIESCING);
            else
            {
                if (publish)
                    return qm.AccessTopic(destName, null, MQC.MQTOPIC_OPEN_AS_PUBLICATION, MQC.MQOO_OUTPUT);
                else
                    return qm.AccessTopic(destName, null, MQC.MQTOPIC_OPEN_AS_SUBSCRIPTION, MQC.MQSO_CREATE
                                                                        | MQC.MQSO_FAIL_IF_QUIESCING | MQC.MQSO_MANAGED | MQC.MQSO_NON_DURABLE);
            }
        }


        /// <summary>
        /// Put/Publish message onto the destination
        /// </summary>
        /// <param name="destName">name of the destination: queueName/topic Name</param>
        /// <param name="isQueue">true, if destination is queue
        ///                       false, if destination is topic </param>
        public void PutMessage(String destName, bool isQueue = true)
        {
            try
            {
                using (var destination = AccessDestination(CreateConnection(), destName, isQueue))
                {
                    var msg = new MQMessage { Persistence = MQC.MQPER_PERSISTENT };
                    msg.WriteString("MQ .NET Application");
                    destination.Put(msg);
                    Console.WriteLine("Message has been put");
                }
            }
            catch (MQException e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Get message from the destination
        /// </summary>
        /// <param name="destName">name of the destination: queueName/topic Name</param>
        /// <param name="isQueue">true, if destination is queue
        ///                       false, if destination is topic </param>
        public void GetMessage(String destName, bool isQueue = true)
        {
            try
            {
                using (var queue = AccessDestination(CreateConnection(), destName, isQueue, false))
                {
                    var msg = new MQMessage();
                    queue.Get(msg);
                    Console.WriteLine("Got the message successfully");
                }
            }
            catch (MQException e)
            {
                throw e;
            }
        }
    }
}
